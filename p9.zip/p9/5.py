import array as arr 

a = arr.array('i',[10,20,30,40,50])
print(a)
a.insert(1,18)
print(a)
