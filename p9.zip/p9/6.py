import array as arr 

a = arr.array('i',[10,20,30,40,50])

a.pop(3)

print(a)
